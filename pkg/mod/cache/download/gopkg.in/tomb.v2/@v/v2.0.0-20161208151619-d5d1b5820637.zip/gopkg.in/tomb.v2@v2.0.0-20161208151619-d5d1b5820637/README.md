Installation and usage
----------------------

See [gopkg.in/tomb.v2](https://gopkg.in/tomb.v2) for documentation and usage details.
